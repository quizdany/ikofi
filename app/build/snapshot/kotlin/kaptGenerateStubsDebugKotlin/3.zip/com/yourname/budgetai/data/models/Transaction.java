package com.yourname.budgetai.data.models;

@kotlin.Metadata(mv = {1, 9, 0}, k = 1, xi = 48, d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0007\n\u0002\b2\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u00ab\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0007\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u000f\u0012\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u0007\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0012\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u000f\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0015\u0012\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0017\u001a\u00020\u0018\u0012\b\b\u0002\u0010\u0019\u001a\u00020\u0012\u0012\b\b\u0002\u0010\u001a\u001a\u00020\u0012\u00a2\u0006\u0002\u0010\u001bJ\t\u00105\u001a\u00020\u0003H\u00c6\u0003J\u000b\u00106\u001a\u0004\u0018\u00010\u0007H\u00c6\u0003J\t\u00107\u001a\u00020\u0012H\u00c6\u0003J\t\u00108\u001a\u00020\u000fH\u00c6\u0003J\t\u00109\u001a\u00020\u0015H\u00c6\u0003J\u0010\u0010:\u001a\u0004\u0018\u00010\u0005H\u00c6\u0003\u00a2\u0006\u0002\u0010\u001fJ\t\u0010;\u001a\u00020\u0018H\u00c6\u0003J\t\u0010<\u001a\u00020\u0012H\u00c6\u0003J\t\u0010=\u001a\u00020\u0012H\u00c6\u0003J\t\u0010>\u001a\u00020\u0005H\u00c6\u0003J\t\u0010?\u001a\u00020\u0007H\u00c6\u0003J\t\u0010@\u001a\u00020\tH\u00c6\u0003J\u000b\u0010A\u001a\u0004\u0018\u00010\u0007H\u00c6\u0003J\u000b\u0010B\u001a\u0004\u0018\u00010\u0007H\u00c6\u0003J\u000b\u0010C\u001a\u0004\u0018\u00010\u0007H\u00c6\u0003J\t\u0010D\u001a\u00020\u0007H\u00c6\u0003J\t\u0010E\u001a\u00020\u000fH\u00c6\u0003J\u00c2\u0001\u0010F\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u00072\b\b\u0002\u0010\r\u001a\u00020\u00072\b\b\u0002\u0010\u000e\u001a\u00020\u000f2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u00072\b\b\u0002\u0010\u0011\u001a\u00020\u00122\b\b\u0002\u0010\u0013\u001a\u00020\u000f2\b\b\u0002\u0010\u0014\u001a\u00020\u00152\n\b\u0002\u0010\u0016\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0017\u001a\u00020\u00182\b\b\u0002\u0010\u0019\u001a\u00020\u00122\b\b\u0002\u0010\u001a\u001a\u00020\u0012H\u00c6\u0001\u00a2\u0006\u0002\u0010GJ\u0013\u0010H\u001a\u00020\u00122\b\u0010I\u001a\u0004\u0018\u00010\u0001H\u00d6\u0003J\t\u0010J\u001a\u00020KH\u00d6\u0001J\t\u0010L\u001a\u00020\u0007H\u00d6\u0001R\u0011\u0010\u0004\u001a\u00020\u0005\u00a2\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0015\u0010\u0016\u001a\u0004\u0018\u00010\u0005\u00a2\u0006\n\n\u0002\u0010 \u001a\u0004\b\u001e\u0010\u001fR\u0013\u0010\u0010\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0011\u0010\u0017\u001a\u00020\u0018\u00a2\u0006\b\n\u0000\u001a\u0004\b#\u0010$R\u0011\u0010\u0013\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b%\u0010&R\u0011\u0010\u0006\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b\'\u0010\"R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004\u00a2\u0006\b\n\u0000\u001a\u0004\b(\u0010)R\u0011\u0010\u0019\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010*R\u0011\u0010\u0011\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010*R\u0011\u0010\u001a\u001a\u00020\u0012\u00a2\u0006\b\n\u0000\u001a\u0004\b+\u0010*R\u0011\u0010\u0014\u001a\u00020\u0015\u00a2\u0006\b\n\u0000\u001a\u0004\b,\u0010-R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b.\u0010\"R\u0013\u0010\n\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b/\u0010\"R\u0011\u0010\r\u001a\u00020\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b0\u0010\"R\u0011\u0010\u000e\u001a\u00020\u000f\u00a2\u0006\b\n\u0000\u001a\u0004\b1\u0010&R\u0013\u0010\f\u001a\u0004\u0018\u00010\u0007\u00a2\u0006\b\n\u0000\u001a\u0004\b2\u0010\"R\u0011\u0010\b\u001a\u00020\t\u00a2\u0006\b\n\u0000\u001a\u0004\b3\u00104\u00a8\u0006M"}, d2 = {"Lcom/yourname/budgetai/data/models/Transaction;", "", "id", "", "amount", "", "currency", "", "transactionType", "Lcom/yourname/budgetai/data/models/TransactionType;", "sender", "receiver", "transactionId", "smsText", "timestamp", "Ljava/util/Date;", "category", "isProcessed", "", "createdAt", "provider", "Lcom/yourname/budgetai/data/models/MobileMoneyProvider;", "balance", "confidence", "", "isAutomatic", "needsReview", "(JDLjava/lang/String;Lcom/yourname/budgetai/data/models/TransactionType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Date;Ljava/lang/String;ZLjava/util/Date;Lcom/yourname/budgetai/data/models/MobileMoneyProvider;Ljava/lang/Double;FZZ)V", "getAmount", "()D", "getBalance", "()Ljava/lang/Double;", "Ljava/lang/Double;", "getCategory", "()Ljava/lang/String;", "getConfidence", "()F", "getCreatedAt", "()Ljava/util/Date;", "getCurrency", "getId", "()J", "()Z", "getNeedsReview", "getProvider", "()Lcom/yourname/budgetai/data/models/MobileMoneyProvider;", "getReceiver", "getSender", "getSmsText", "getTimestamp", "getTransactionId", "getTransactionType", "()Lcom/yourname/budgetai/data/models/TransactionType;", "component1", "component10", "component11", "component12", "component13", "component14", "component15", "component16", "component17", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "(JDLjava/lang/String;Lcom/yourname/budgetai/data/models/TransactionType;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/Date;Ljava/lang/String;ZLjava/util/Date;Lcom/yourname/budgetai/data/models/MobileMoneyProvider;Ljava/lang/Double;FZZ)Lcom/yourname/budgetai/data/models/Transaction;", "equals", "other", "hashCode", "", "toString", "app_debug"})
@androidx.room.Entity(tableName = "transactions")
public final class Transaction {
    @androidx.room.PrimaryKey(autoGenerate = true)
    private final long id = 0L;
    private final double amount = 0.0;
    @org.jetbrains.annotations.NotNull
    private final java.lang.String currency = null;
    @org.jetbrains.annotations.NotNull
    private final com.yourname.budgetai.data.models.TransactionType transactionType = null;
    @org.jetbrains.annotations.Nullable
    private final java.lang.String sender = null;
    @org.jetbrains.annotations.Nullable
    private final java.lang.String receiver = null;
    @org.jetbrains.annotations.Nullable
    private final java.lang.String transactionId = null;
    @org.jetbrains.annotations.NotNull
    private final java.lang.String smsText = null;
    @org.jetbrains.annotations.NotNull
    private final java.util.Date timestamp = null;
    @org.jetbrains.annotations.Nullable
    private final java.lang.String category = null;
    private final boolean isProcessed = false;
    @org.jetbrains.annotations.NotNull
    private final java.util.Date createdAt = null;
    @org.jetbrains.annotations.NotNull
    private final com.yourname.budgetai.data.models.MobileMoneyProvider provider = null;
    @org.jetbrains.annotations.Nullable
    private final java.lang.Double balance = null;
    private final float confidence = 0.0F;
    private final boolean isAutomatic = false;
    private final boolean needsReview = false;
    
    public Transaction(long id, double amount, @org.jetbrains.annotations.NotNull
    java.lang.String currency, @org.jetbrains.annotations.NotNull
    com.yourname.budgetai.data.models.TransactionType transactionType, @org.jetbrains.annotations.Nullable
    java.lang.String sender, @org.jetbrains.annotations.Nullable
    java.lang.String receiver, @org.jetbrains.annotations.Nullable
    java.lang.String transactionId, @org.jetbrains.annotations.NotNull
    java.lang.String smsText, @org.jetbrains.annotations.NotNull
    java.util.Date timestamp, @org.jetbrains.annotations.Nullable
    java.lang.String category, boolean isProcessed, @org.jetbrains.annotations.NotNull
    java.util.Date createdAt, @org.jetbrains.annotations.NotNull
    com.yourname.budgetai.data.models.MobileMoneyProvider provider, @org.jetbrains.annotations.Nullable
    java.lang.Double balance, float confidence, boolean isAutomatic, boolean needsReview) {
        super();
    }
    
    public final long getId() {
        return 0L;
    }
    
    public final double getAmount() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.lang.String getCurrency() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final com.yourname.budgetai.data.models.TransactionType getTransactionType() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String getSender() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String getReceiver() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String getTransactionId() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.lang.String getSmsText() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.util.Date getTimestamp() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String getCategory() {
        return null;
    }
    
    public final boolean isProcessed() {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.util.Date getCreatedAt() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final com.yourname.budgetai.data.models.MobileMoneyProvider getProvider() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.Double getBalance() {
        return null;
    }
    
    public final float getConfidence() {
        return 0.0F;
    }
    
    public final boolean isAutomatic() {
        return false;
    }
    
    public final boolean getNeedsReview() {
        return false;
    }
    
    public final long component1() {
        return 0L;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String component10() {
        return null;
    }
    
    public final boolean component11() {
        return false;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.util.Date component12() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final com.yourname.budgetai.data.models.MobileMoneyProvider component13() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.Double component14() {
        return null;
    }
    
    public final float component15() {
        return 0.0F;
    }
    
    public final boolean component16() {
        return false;
    }
    
    public final boolean component17() {
        return false;
    }
    
    public final double component2() {
        return 0.0;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.lang.String component3() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final com.yourname.budgetai.data.models.TransactionType component4() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String component5() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String component6() {
        return null;
    }
    
    @org.jetbrains.annotations.Nullable
    public final java.lang.String component7() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.lang.String component8() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final java.util.Date component9() {
        return null;
    }
    
    @org.jetbrains.annotations.NotNull
    public final com.yourname.budgetai.data.models.Transaction copy(long id, double amount, @org.jetbrains.annotations.NotNull
    java.lang.String currency, @org.jetbrains.annotations.NotNull
    com.yourname.budgetai.data.models.TransactionType transactionType, @org.jetbrains.annotations.Nullable
    java.lang.String sender, @org.jetbrains.annotations.Nullable
    java.lang.String receiver, @org.jetbrains.annotations.Nullable
    java.lang.String transactionId, @org.jetbrains.annotations.NotNull
    java.lang.String smsText, @org.jetbrains.annotations.NotNull
    java.util.Date timestamp, @org.jetbrains.annotations.Nullable
    java.lang.String category, boolean isProcessed, @org.jetbrains.annotations.NotNull
    java.util.Date createdAt, @org.jetbrains.annotations.NotNull
    com.yourname.budgetai.data.models.MobileMoneyProvider provider, @org.jetbrains.annotations.Nullable
    java.lang.Double balance, float confidence, boolean isAutomatic, boolean needsReview) {
        return null;
    }
    
    @java.lang.Override
    public boolean equals(@org.jetbrains.annotations.Nullable
    java.lang.Object other) {
        return false;
    }
    
    @java.lang.Override
    public int hashCode() {
        return 0;
    }
    
    @java.lang.Override
    @org.jetbrains.annotations.NotNull
    public java.lang.String toString() {
        return null;
    }
}