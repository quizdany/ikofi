package com.yourname.budgetai.ui.theme;

@kotlin.Metadata(mv = {1, 9, 0}, k = 2, xi = 48, d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b9\"\u001a\u0010\u0000\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001\u00f8\u0001\u0000\u00a2\u0006\b\n\u0000\u001a\u0004\b\u0003\u0010\u0004\"\u0016\u0010\u0005\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0006\u0010\u0007\"\u0016\u0010\t\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\n\u0010\u0007\"\u0016\u0010\u000b\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\f\u0010\u0007\"\u0016\u0010\r\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u000e\u0010\u0007\"\u0016\u0010\u000f\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0010\u0010\u0007\"\u0016\u0010\u0011\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0012\u0010\u0007\"\u0016\u0010\u0013\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0014\u0010\u0007\"\u0016\u0010\u0015\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0016\u0010\u0007\"\u0016\u0010\u0017\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u0018\u0010\u0007\"\u0016\u0010\u0019\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u001a\u0010\u0007\"\u0016\u0010\u001b\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u001c\u0010\u0007\"\u0016\u0010\u001d\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\u001e\u0010\u0007\"\u0016\u0010\u001f\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b \u0010\u0007\"\u0016\u0010!\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b\"\u0010\u0007\"\u0016\u0010#\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b$\u0010\u0007\"\u0016\u0010%\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b&\u0010\u0007\"\u0016\u0010\'\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b(\u0010\u0007\"\u0016\u0010)\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b*\u0010\u0007\"\u0016\u0010+\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b,\u0010\u0007\"\u0016\u0010-\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b.\u0010\u0007\"\u0016\u0010/\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b0\u0010\u0007\"\u0016\u00101\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b2\u0010\u0007\"\u0016\u00103\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b4\u0010\u0007\"\u0016\u00105\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b6\u0010\u0007\"\u0016\u00107\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b8\u0010\u0007\"\u0016\u00109\u001a\u00020\u0002\u00f8\u0001\u0000\u00a2\u0006\n\n\u0002\u0010\b\u001a\u0004\b:\u0010\u0007\u0082\u0002\u0004\n\u0002\b\u0019\u00a8\u0006;"}, d2 = {"ChartColors", "", "Landroidx/compose/ui/graphics/Color;", "getChartColors", "()Ljava/util/List;", "CyberPink", "getCyberPink", "()J", "J", "DangerRed", "getDangerRed", "DarkBackground", "getDarkBackground", "DarkCard", "getDarkCard", "DarkOnSurface", "getDarkOnSurface", "DarkSurface", "getDarkSurface", "ElectricBlue", "getElectricBlue", "GlassBlur", "getGlassBlur", "GlassDark", "getGlassDark", "GlassLight", "getGlassLight", "InfoBlue", "getInfoBlue", "LightBackground", "getLightBackground", "LightCard", "getLightCard", "LightOnSurface", "getLightOnSurface", "LightSurface", "getLightSurface", "NeonBlue", "getNeonBlue", "NeonGreen", "getNeonGreen", "NeonPurple", "getNeonPurple", "Pink40", "getPink40", "Pink80", "getPink80", "Purple40", "getPurple40", "Purple80", "getPurple80", "PurpleGrey40", "getPurpleGrey40", "PurpleGrey80", "getPurpleGrey80", "SuccessGreen", "getSuccessGreen", "WarningOrange", "getWarningOrange", "app_release"})
public final class ColorKt {
    private static final long Purple80 = 0L;
    private static final long PurpleGrey80 = 0L;
    private static final long Pink80 = 0L;
    private static final long Purple40 = 0L;
    private static final long PurpleGrey40 = 0L;
    private static final long Pink40 = 0L;
    private static final long NeonBlue = 0L;
    private static final long NeonPurple = 0L;
    private static final long NeonGreen = 0L;
    private static final long ElectricBlue = 0L;
    private static final long CyberPink = 0L;
    private static final long DarkSurface = 0L;
    private static final long DarkBackground = 0L;
    private static final long DarkCard = 0L;
    private static final long DarkOnSurface = 0L;
    private static final long LightSurface = 0L;
    private static final long LightBackground = 0L;
    private static final long LightCard = 0L;
    private static final long LightOnSurface = 0L;
    private static final long GlassLight = 0L;
    private static final long GlassDark = 0L;
    private static final long GlassBlur = 0L;
    private static final long SuccessGreen = 0L;
    private static final long WarningOrange = 0L;
    private static final long DangerRed = 0L;
    private static final long InfoBlue = 0L;
    @org.jetbrains.annotations.NotNull
    private static final java.util.List<androidx.compose.ui.graphics.Color> ChartColors = null;
    
    public static final long getPurple80() {
        return 0L;
    }
    
    public static final long getPurpleGrey80() {
        return 0L;
    }
    
    public static final long getPink80() {
        return 0L;
    }
    
    public static final long getPurple40() {
        return 0L;
    }
    
    public static final long getPurpleGrey40() {
        return 0L;
    }
    
    public static final long getPink40() {
        return 0L;
    }
    
    public static final long getNeonBlue() {
        return 0L;
    }
    
    public static final long getNeonPurple() {
        return 0L;
    }
    
    public static final long getNeonGreen() {
        return 0L;
    }
    
    public static final long getElectricBlue() {
        return 0L;
    }
    
    public static final long getCyberPink() {
        return 0L;
    }
    
    public static final long getDarkSurface() {
        return 0L;
    }
    
    public static final long getDarkBackground() {
        return 0L;
    }
    
    public static final long getDarkCard() {
        return 0L;
    }
    
    public static final long getDarkOnSurface() {
        return 0L;
    }
    
    public static final long getLightSurface() {
        return 0L;
    }
    
    public static final long getLightBackground() {
        return 0L;
    }
    
    public static final long getLightCard() {
        return 0L;
    }
    
    public static final long getLightOnSurface() {
        return 0L;
    }
    
    public static final long getGlassLight() {
        return 0L;
    }
    
    public static final long getGlassDark() {
        return 0L;
    }
    
    public static final long getGlassBlur() {
        return 0L;
    }
    
    public static final long getSuccessGreen() {
        return 0L;
    }
    
    public static final long getWarningOrange() {
        return 0L;
    }
    
    public static final long getDangerRed() {
        return 0L;
    }
    
    public static final long getInfoBlue() {
        return 0L;
    }
    
    @org.jetbrains.annotations.NotNull
    public static final java.util.List<androidx.compose.ui.graphics.Color> getChartColors() {
        return null;
    }
}